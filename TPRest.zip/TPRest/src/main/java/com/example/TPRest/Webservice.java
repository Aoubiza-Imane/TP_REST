package com.example.TPRest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;

@RestController
@RequestMapping("api")
public class Webservice {
    Contacts contacts = new Contacts();

    public Webservice() {
        readFromXml();
    }

    /*@GetMapping(value = "/contacts", produces = {"application/xml","application/json"})
    Contacts getContacts() {
        return contacts;
    }*/

    /*@GetMapping(value = "/contacts", produces = {"application/xml","application/json"})
    Contacts getContacts(HttpServletRequest request) {
        System.out.println(request.getRequestURL());
        return contacts;
    }*/

    @GetMapping(value = "/contacts", produces = {"application/xml","application/json"})
    Contacts getContacts(HttpServletRequest request, @RequestParam(defaultValue = "0") int annee) {
        if (annee!=0){
            Contacts cAnnee = new Contacts();
            for (Contact c : contacts.getContacts()) {
                if (annee==c.getAnnee()){
                    cAnnee.getContacts().add(c);
                }
            }
            return cAnnee;
        }
        System.out.println(request.getRequestURL());
        return contacts;
    }

    @PostMapping(value = "/contacts", consumes = {"application/xml","application/json"})
    Contacts newContact(@RequestBody Contact contact) {
        int idMax = 0;
        for (Contact c : contacts.getContacts()) {
            if (idMax < c.getId()) {
                idMax = c.getId();
            }
        }
        contact.setId(idMax + 1);
        contacts.getContacts().add(contact);
        saveToXml();
        return contacts;
    }

    String path = "c:/temp";

    private void readFromXml() {
        JAXBContext jaxbContext;
        try {
            jaxbContext = JAXBContext.newInstance(Contacts.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            File f = new File(path + "/contacts.xml");
            contacts = (Contacts) jaxbUnmarshaller.unmarshal(f);
        } catch (Exception ex) {
            System.out.println("Erreur lecture du fichier:" + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void saveToXml() {
        JAXBContext jaxbContext;
        try {
            jaxbContext = JAXBContext.newInstance(Contacts.class);
            Marshaller march = jaxbContext.createMarshaller();
            march.marshal(contacts, new File(path + "/contacts.xml"));
        } catch (Exception ex) {
            System.out.println("Erreur écriture du fichier:" + ex.getMessage());
            ex.printStackTrace();
        }
    }

    /*@DeleteMapping(value = "/contact/{id}", produces = "application/xml")
    Contacts deleteContact(@PathVariable int id) {
        for (Contact c : contacts.getContacts()) {
            if (c.getId() == id) {
                contacts.getContacts().remove(c);
            }
        }
        return contacts;
    }*/

    @DeleteMapping(value="/contact/{id}")
    ResponseEntity deleteContact(@PathVariable int id) {
        Contact contact = null;
        for (Contact c : contacts.getContacts()) {
            if (c.getId() == id) contact = c;
        }
        if (contact != null) {
            contacts.getContacts().remove(contact);
            return new ResponseEntity(contacts, HttpStatus.OK);
        }
        else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }



    @GetMapping(value = "/contacts/{id}", produces = "application/xml")
    Contact getContact(@PathVariable int id) {
        Contact co = null;
        for (Contact c : contacts.getContacts()) {
            if (c.getId() == id) {
                co = c;
            }

        }
        return co;
    }

    @PutMapping(value = "/contacts/{id}", produces = "application/xml")
    Contacts editContact(@PathVariable int id, @RequestBody Contact contact) {
        for (Contact c : contacts.getContacts()) {
            if (c.getId() == id) {
                c.setNom(contact.getNom());
                c.setPrenom(contact.getPrenom());
                c.setAnnee(contact.getAnnee());
            }
        }
        return contacts;
    }

}

